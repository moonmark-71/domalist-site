// src/pages/SellernoteList.js
import React, { useEffect, useState } from "react";
import { db } from "../firebase"; // Firebase 연결한 파일
import { collection, getDocs, query, orderBy } from "firebase/firestore";
import { Link } from "react-router-dom";

const SellernoteList = () => {
  const [notes, setNotes] = useState([]);

  useEffect(() => {
    const fetchNotes = async () => {
      const q = query(collection(db, "sellernotes"), orderBy("createdAt", "desc"));
      const snapshot = await getDocs(q);
      const noteList = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setNotes(noteList);
    };
    fetchNotes();
  }, []);

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">📒 셀러노트</h1>
      <div className="space-y-4">
        {notes.map(note => (
          <Link to={`/sellernote/${note.id}`} key={note.id}>
            <div className="p-4 border rounded-xl hover:bg-gray-50">
              <h2 className="text-xl font-semibold">{note.title}</h2>
              <p className="text-sm text-gray-500">
                {new Date(note.createdAt.seconds * 1000).toLocaleDateString()}
              </p>
              <p className="mt-2 text-gray-700 line-clamp-2">
                {note.content.slice(0, 100)}...
              </p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default SellernoteList;
