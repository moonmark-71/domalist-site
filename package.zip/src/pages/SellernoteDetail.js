// 파일: src/pages/SellernoteDetail.js

import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { doc, getDoc } from "firebase/firestore";
import { db } from "../firebase";

const SellernoteDetail = () => {
  const { id } = useParams();
  const [note, setNote] = useState(null);

  useEffect(() => {
    const fetchNote = async () => {
      const docRef = doc(db, "sellernotes", id);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        setNote(docSnap.data());
      } else {
        console.log("No such document!");
      }
    };
    fetchNote();
  }, [id]);

  if (!note) return <p className="p-6">로딩 중...</p>;

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-2">{note.title}</h1>
      <p className="text-sm text-gray-500 mb-4">
        작성일: {new Date(note.createdAt.seconds * 1000).toLocaleDateString()}
      </p>
      <div className="prose max-w-none">{note.content}</div>
    </div>
  );
};

export default SellernoteDetail;
