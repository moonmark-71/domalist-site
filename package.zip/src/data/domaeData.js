// src/data/domaeData.js
const domaelist = [
    {
      id: 1,
      name: "패션도매 A",
      category: "패션",
      delivery: "가능",
      purchase: "불가",
      international: "불가",
      contact: "010-1234-5678",
      website: "https://fashion-a.com"
    },
    {
      id: 2,
      name: "리빙도매 B",
      category: "리빙",
      delivery: "불가",
      purchase: "가능",
      international: "가능",
      contact: "010-5678-4321",
      website: "https://living-b.com"
    }
  ];
  
  export default domaelist;
  