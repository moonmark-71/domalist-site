// setAdminClaim.js - 특정 사용자에게 관리자 권한(role: "admin") 부여
const admin = require("firebase-admin");

// 🔐 비공개 키 JSON 경로 (정확하게 입력됨)
const serviceAccount = require("./domae-platform-firebase-adminsdk-fbsvc-4608db0959.json");

// 🔧 Firebase Admin 초기화
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

// ✅ 여기에 관리자 UID 넣기
const uid = "OjLaHqHogPWOA53xT87xDq481hA3"; // 예: "0jLaHQHogPWOA53xT87xDq..."

admin.auth().setCustomUserClaims(uid, { role: "admin" })
  .then(() => {
    console.log("✅ 관리자 권한 부여 완료!");
  })
  .catch((error) => {
    console.error("❌ 관리자 권한 설정 실패:", error);
  });
