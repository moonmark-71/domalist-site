// src/App.js
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import MainLayout from "./layouts/MainLayout";
// … 나머지 import 생략 …

function App() {
  return (
    <Router>
      {/* MainLayout 안에서 Header, 광고, 그리고 children이 렌더링 됩니다 */}
      <MainLayout>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/list" element={<WholesalerList />} />
          <Route path="/wholesaler/:id" element={<WholesalerDetail />} />
          <Route path="/article" element={<ArticlePage />} />
          <Route path="/search" element={<SearchPage />} />
          <Route path="/seller-info" element={<SellerInfoCenter />} />
          <Route path="/admin-login" element={<AdminLogin />} />
          <Route path="/admin/clean-categories" element={<CategoryCleaner />} />
          <Route
            path="/admin"
            element={
              <ProtectedRoute>
                <AdminPanel />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/add"
            element={
              <ProtectedRoute>
                <AdminAddWholesaler />
              </ProtectedRoute>
            }
          />
          <Route path="/seller-support" element={<SellerSupport />} />
        </Routes>
      </MainLayout>
    </Router>
  );
}

export default App;
