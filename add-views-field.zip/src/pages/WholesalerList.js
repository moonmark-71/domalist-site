// src/pages/WholesalerList.js
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import MainLayout from "../layouts/MainLayout";   // default export 확인!
import {
  collection,
  getDocs,
  doc,
  updateDoc,
  increment,
  query,
  orderBy,
} from "firebase/firestore";
import { db } from "../firebase";

export default function WholesalerList() {
  const [wholesalers, setWholesalers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        // views 내림차순 조회 (views 필드가 없는 문서도 나오게 하려면 orderBy 제거)
        const q = query(
          collection(db, "wholesalers"),
          orderBy("views", "desc")
        );
        const snap = await getDocs(q);
        setWholesalers(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
      } catch (e) {
        console.error("데이터 로드 오류:", e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  return (
    <MainLayout>
      {loading ? (
        <p className="text-center py-10">로딩 중…</p>
      ) : (
        <div className="max-w-[1040px] mx-auto grid gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
          {wholesalers.map((w, idx) => {
            // logoUrl이나 siteUrl이 없을 때 대비
            const logo =
              w.logoUrl && w.logoUrl.startsWith("http")
                ? w.logoUrl
                : "/placeholder.svg";
            const site = w.siteUrl
              ? w.siteUrl.startsWith("http")
                ? w.siteUrl
                : `https://${w.siteUrl}`
              : "#";

            return (
              <div
                key={w.id}
                className="bg-white p-4 rounded-xl shadow hover:shadow-lg transition"
              >
                <Link to={`/wholesaler/${w.id}`}>
                  <img
                    src={logo}
                    alt={w.name}
                    className="w-full h-32 object-cover rounded-lg mb-3"
                  />
                </Link>

                <h2 className="text-lg font-semibold flex items-center justify-between">
                  <Link
                    to={`/wholesaler/${w.id}`}
                    className="hover:underline flex-1"
                  >
                    {w.name}
                  </Link>
                  {idx < 3 && (
                    <span className="ml-2 text-yellow-400">★ 인기</span>
                  )}
                </h2>

                <p className="text-sm text-gray-500 mb-2">{w.category}</p>

                <a
                  href={site}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={async () => {
                    try {
                      await updateDoc(doc(db, "wholesalers", w.id), {
                        views: increment(1),
                      });
                    } catch (e) {
                      console.error("조회수 업데이트 실패:", e);
                    }
                  }}
                  className="block mt-3 w-full text-center bg-indigo-600 text-white py-2 rounded-lg"
                >
                  🌐 웹사이트 방문
                </a>
              </div>
            );
          })}
        </div>
      )}
    </MainLayout>
  );
}
