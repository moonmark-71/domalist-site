import React from "react";

const SearchPage = () => {
  return (
    <div className="min-h-screen p-8 bg-white">
      <h1 className="text-2xl font-bold mb-4">🔍 상품 검색</h1>
      <p className="text-gray-600">이곳은 상품 키워드 기반 검색 페이지입니다. 추후 검색 기능 추가 예정입니다.</p>
    </div>
  );
};

export default SearchPage;
