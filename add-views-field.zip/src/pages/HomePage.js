/* -------------------------------------------------------------
   src/pages/HomePage.js
   - 그리드 ◻ / 리스트 ≡ 토글
   - 카테고리 필터 탭
   - 검색 입력창
   ------------------------------------------------------------- */
   import React, { useState } from "react";

   import useWholesalers   from "../hooks/useWholesalers";
   import ViewToggle       from "../components/ViewToggle";
   import CategoryTabs     from "../components/CategoryTabs";
   import LogoBox          from "../components/LogoBox";
   import WholesalerCard   from "../components/WholesalerCard";
   
   function HomePage() {
     /* --------------------- 상태 --------------------- */
     const [view, setView]   = useState("grid");   // grid | list
     const [cat,  setCat]    = useState(null);     // 카테고리( null = 전체 )
     const [kw,   setKw]     = useState("");       // 검색 키워드
   
     /* --------------------- 데이터 -------------------- */
     const raw   = useWholesalers(cat);            // 카테고리 필터
     const data  = kw
       ? raw.filter(
           (w) =>
             w.name.includes(kw) ||
             (w.summary && w.summary.includes(kw))
         )
       : raw;                                       // 검색 필터
   
     /* --------------------- JSX ---------------------- */
     return (
       <main className="max-w-6xl mx-auto px-4 py-8">
   
         {/* 헤더(히어로) ------------------------------------------------ */}
         <section className="mb-10 text-center">
           <h1 className="text-3xl md:text-4xl font-extrabold leading-tight">
             국내 도매&nbsp;·&nbsp;위탁 판매처를 <br className="sm:hidden"/>한눈에!
           </h1>
           <p className="mt-3 text-gray-600">
             카테고리·혜택·정책 비교하고, 바로 방문해 보세요.
           </p>
         </section>
   
         {/* 툴바 : 검색 + 토글 ---------------------------------------- */}
         <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
           {/* 검색창 */}
           <input
             value={kw}
             onChange={(e) => setKw(e.target.value)}
             placeholder="업체명 검색"
             className="border px-3 py-1 rounded-md w-full sm:w-60"
           />
   
           {/* 그리드/리스트 토글 */}
           <ViewToggle view={view} setView={setView} />
         </div>
   
         {/* 카테고리 탭 ----------------------------------------------- */}
         <CategoryTabs selectedCat={cat} setSelectedCat={setCat} />
   
         {/* 카드/로고 렌더 ------------------------------------------- */}
         <section
           className={
             view === "grid"
               ? "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 mt-4"
               : "flex flex-col gap-4 mt-4"
           }
         >
           {data.length === 0 ? (
             <p className="text-sm text-gray-500">조건에 맞는 업체가 없습니다.</p>
           ) : (
             data.map((w) =>
               view === "grid" ? (
                 <LogoBox key={w.id} w={w} />
               ) : (
                 <WholesalerCard key={w.id} w={w} />
               )
             )
           )}
         </section>
       </main>
     );
   }
   
   export default HomePage;
   