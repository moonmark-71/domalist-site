// src/layouts/MainLayout.js
import React from "react";
import Header from "../components/Header";

export default function MainLayout({ children }) {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* 상단 내비게이션 */}
      <Header />

      {/* ───── 3단 그리드: 300px / auto / 300px ───── */}
      <div
        className="
          grid gap-4
          lg:grid-cols-[300px_minmax(0,1fr)_300px]
          max-w-[1600px] mx-auto
          px-4 sm:px-6 lg:px-8 py-6
        "
      >
        {/* 왼쪽 사이드 광고 (1024px 이상에서만 보여 줌) */}
        <aside className="hidden lg:block">
          <AdBox />
        </aside>

        {/* 메인 컨텐츠 영역 */}
        <main className="max-w-[1040px] mx-auto">
          {children}
        </main>

        {/* 오른쪽 사이드 광고 (1024px 이상에서만 보여 줌) */}
        <aside className="hidden lg:block">
          <AdBox />
        </aside>
      </div>
    </div>
  );
}

/**
 * AdBox 컴포넌트 (임시 광고 영역)
 * 실제 광고 스크립트나 이미지 URL로 교체하세요.
 */
function AdBox() {
  return (
    <div className="sticky top-24">
      {/* 광고 이미지 예시 */}
      <img
        src="/ad-sample.jpg"
        alt="광고 배너"
        className="w-full rounded-xl shadow"
      />
    </div>
  );
}
