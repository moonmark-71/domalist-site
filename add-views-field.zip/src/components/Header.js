// src/components/Header.js
import React from "react";
import { Link, NavLink } from "react-router-dom";

const linkStyle =
  "hover:text-indigo-600 transition-colors";
const activeStyle =
  "text-indigo-600 font-semibold";

export default function Header() {
  return (
    <header className="bg-white border-b shadow-sm sticky top-0 z-50">
 <div className="max-w-7xl mx-auto px-6 py-5 flex items-center justify-between">
        {/* ① 타이틀 → 홈 링크 */}
        <Link
          to="/"
          className="text-3xl font-extrabold text-indigo-600 tracking-tight"
        >
          JB도매리스트
        </Link>

        {/* ② NavLink 로 active 스타일 */}
        <nav className="hidden sm:flex gap-8 text-base font-semibold text-gray-700">
          <NavLink
            to="/list"
            className={({ isActive }) =>
              (isActive ? activeStyle : "") + " " + linkStyle
            }
          >
            도매사이트
          </NavLink>

          <NavLink
            to="/search"
            className={({ isActive }) =>
              (isActive ? activeStyle : "") + " " + linkStyle
            }
          >
            상품 검색
          </NavLink>

          <NavLink
            to="/seller-info"
            className={({ isActive }) =>
              (isActive ? activeStyle : "") + " " + linkStyle
            }
          >
            셀러정보센터
          </NavLink>

          <NavLink
            to="/article"
            className={({ isActive }) =>
              (isActive ? activeStyle : "") + " " + linkStyle
            }
          >
            콘텐츠
          </NavLink>

          <NavLink
            to="/seller-support"
            className={({ isActive }) =>
              (isActive ? activeStyle : "") + " " + linkStyle
            }
          >
            정책지원
          </NavLink>

          <NavLink
            to="/admin-login"
            className={({ isActive }) =>
              (isActive ? activeStyle : "text-blue-500") + " " + linkStyle
            }
          >
            로그인
          </NavLink>
        </nav>
      </div>
    </header>
  );
}
