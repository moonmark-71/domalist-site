export default function LogoBoxSkeleton() {
    return (
      <div className="h-20 rounded-2xl bg-gray-100 animate-pulse" />
    );
  }
  