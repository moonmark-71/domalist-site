import React from "react";

const CATS = ["전체", "종합", "식품", "생활", "패션", "디지털", "반려"];

export default function CategoryTabs({ selectedCat, setSelectedCat }) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-2">
      {CATS.map((c) => {
        const active = selectedCat === c || (!selectedCat && c === "전체");
        return (
          <button
            key={c}
            onClick={() => setSelectedCat(c === "전체" ? null : c)}
            className={
              `px-3 py-1 text-sm rounded-full border transition ` +
              (active
                ? "bg-indigo-600 text-white"
                : "bg-white hover:bg-gray-100")
            }
          >
            {c}
          </button>
        );
      })}
    </div>
  );
}
