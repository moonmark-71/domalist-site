// src/components/WholesalerCard.js
import React from "react";

/**
 * props.w =
 * {
 *   name:      string,
 *   summary:   string,
 *   siteUrl:   string,
 *   logoUrl:   string  (없으면 placeholder.svg 로 대체)
 * }
 */
export default function WholesalerCard({ w }) {
  return (
    <div className="flex items-center gap-4 rounded-2xl shadow-sm hover:shadow-md bg-white p-4">
      {/* 로고 */}
      <img
        src={w.logoUrl || "/placeholder.svg"}
        alt={w.name}
        className="h-10 w-10 object-contain rounded-md bg-gray-50"
      />

      {/* 텍스트 */}
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold truncate">{w.name}</p>
        {w.summary && (
          <p className="text-xs text-gray-500 line-clamp-2">{w.summary}</p>
        )}
      </div>

      {/* 사이트 바로가기 버튼 */}
      <a
        href={w.siteUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="px-3 py-1 text-xs font-medium rounded-md border border-gray-300 hover:bg-gray-100 whitespace-nowrap"
      >
        사이트 방문
      </a>
    </div>
  );
}
